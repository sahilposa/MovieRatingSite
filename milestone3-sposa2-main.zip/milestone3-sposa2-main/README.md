Project Milestone 3
1. One would need to download requests, Flask, python-dotenv, flask-login, and flask-sqlalchemy and psycopg2. Create a Procfile correctly and procure an API key from the TMDB website to keep in a .env file named as "API_KEY" and export it. Remember to do .gitignore. Set up a postgresql database and put the URL to it in your .env file named as "DATABASE_URL". You will also need to create a secret key in your .env and name it "SECRET_KEY" To run the app, type python3 app.py into the terminal and it should run. One should also install npm and react into the system to utilize react.
2. This implementation was extremely difficult and ultimately I couldn't figure it out in time at all. I found the similar codes from peers regarding the javascript to create the buttons for saving comments and such but they just would not show up. I could not understand how to merge what I learned from hw7 into this project. 
3. This project milestone 3 was absolutely taxing on me and I ultimately could not figure out anything despite help from my peers. Javascript, despite me being able to complete hw7, was impossible for me to crack and merge with what I had created in milestone 2.

___________________________________________________________

Project Milestone 2
1. One would need to download requests, Flask, python-dotenv, flask-login, and flask-sqlalchemy and psycopg2. Create a Procfile correctly and procure an API key to keep in a .env file named as "API_KEY" and export it. Remember to do .gitignore. Set up a postgresql database and put the URL to it in your .env file named as "DATABASE_URL". You will also need to create a secret key in your .env and name it "SECRET_KEY" To run the app, type python3 app.py into the terminal and it should run.
2. This implementation differed greatly from what I had initially thought as I hadn't realized exactly that I needed to use a models.py file to create all my databases and such. I had to find out how to do so with help from the Discord and sources online given in the Milestone Specs google docs.
3. Two technical issues that I ran into were trying to implement the user login and registration aspects, specifically running into trouble as to how to work with the Users class and how to make the two pages go back and forth between the two, and combining the random movies with the databases for Movie Ratings. To resolve these, I had to use the documentations as well as asking help from my peers and my father in terms of constructing the databases and then filling them with values of users and movies, as well as movie ratings.

Link to App: https://ancient-thicket-83002.herokuapp.com

_________________________________________________________

Project Milestone 1
1. One would need to download wikipedia-api, requests, Flask, and python-dotenv. Create a Procfile correctly and procure an API key to keep in a .env file. Remember to do .gitignore. This should be sufficient enough to run this locally.
2. Things I would have added to this would have been a link to the soundtrack of the movie on Spotify if it exists, as well as a link to the youtube highlight playlist of said movie.
3. One technical issue was trying to get the genres to show correctly for the tmdb.py. I had to search for and ask multiple people for help such as Brian Williams on how to get only the genre names to display, until finally I figured out the for loop PROPERLY. Another technical issue was getting the image to display itself properly and correctly, which I found out by searching for various HTML help sources on how to include the poster_path.


Link to App: https://mysterious-sands-60042.herokuapp.com
