import './App.css';
import React, { useState, useEffect } from "react";

  let url = '/comments'

function Comment(props){
  return(
    <div>
      {props.value}
      <button> Delete Comment</button>
    </div>
  );
}
function CommentsHandling(){
  const [Comments, setComments]=useState([]);

  useEffect(() => {
    fetch(url).then(res => res.json()).then(data => setComments(data));
  },[])
  function renderComment(i){
    {Comments.map((item)=>
    <form>
      <input value={item.rating}/><input value={item.Comment}/><button>Delete</button>
    </form>)}
  }
  return(
    <div>
    {Comments.map((item)=>
      <form>
      <input value={item.rating}/><input value={item.review}/><button>Delete</button>
      </form>)}
    );
    </div>
  )}

function App() {
   const HandleClick = () => {
     fetch("/funfact").then(response => 
       response.json()).then(data => 
         setFact(data));
   }
  const [Comments, setComments]=useState([]);
  function saveComments(){
    fetch('/savecomments', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(Comments)
    }
    ).then(res => res.json()).catch(error => console.log(error));
  }
  useEffect(() => {
    fetch(url,{
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({comments: comment})
    }).then(res => res.json().then(data =>setComments(data)));
  }, []);
  return (
    <div className="App">
      <h1>Comments</h1>
      <div>
        {Comments.map((item) => 
        <form>
          <label>Movie ID: {item.movieid}</label><input value={item.rating}/><input value={item.review}/><button>Delete</button>
        </form>
        )}
        <button>Save Changes</button>
      </div>
    </div>
  );
}

export default App;
